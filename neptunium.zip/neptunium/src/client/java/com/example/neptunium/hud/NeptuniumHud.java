package com.example.neptunium.hud;

import com.example.neptunium.config.NeptuniumConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.opengl.GL11;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class NeptuniumHud {
    private NeptuniumHud() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) {
            return;
        }

        List<String> lines = new ArrayList<>();
        if (NeptuniumConfig.get("fps")) {
            lines.add("FPS: " + mc.getCurrentFps());
        }
        if (NeptuniumConfig.get("xyz")) {
            lines.add(String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (NeptuniumConfig.get("facing")) {
            lines.add("Yo'nalish: " + mc.player.getHorizontalFacing().asString());
        }
        if (NeptuniumConfig.get("chunk")) {
            lines.add("Chunk: " + mc.player.getChunkPos().x + ", " + mc.player.getChunkPos().z);
        }
        if (NeptuniumConfig.get("memory")) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            long max = rt.maxMemory() / 1048576L;
            lines.add("RAM: " + used + "/" + max + " MB");
        }
        if (NeptuniumConfig.get("clock")) {
            lines.add("Soat: " + LocalTime.now().withNano(0));
        }
        if (NeptuniumConfig.get("worldtime") && mc.world != null) {
            lines.add("Dunyo vaqti: " + (mc.world.getTimeOfDay() % 24000L));
        }
        if (NeptuniumConfig.get("java")) {
            lines.add("Java: " + System.getProperty("java.version"));
        }
        if (NeptuniumConfig.get("resolution")) {
            lines.add("Ekran: " + mc.getWindow().getWidth() + "x" + mc.getWindow().getHeight());
        }
        if (NeptuniumConfig.get("gpu")) {
            String gpu;
            try {
                gpu = GL11.glGetString(GL11.GL_RENDERER);
            } catch (RuntimeException e) {
                gpu = "noma'lum";
            }
            lines.add("GPU: " + gpu);
        }

        boolean bg = NeptuniumConfig.get("hudbg");
        int y = 4;
        for (String line : lines) {
            int width = mc.textRenderer.getWidth(line);
            if (bg) {
                context.fill(2, y - 1, 6 + width, y + 9, 0x88000000);
            }
            context.drawTextWithShadow(mc.textRenderer, line, 4, y, 0xFFFFFF);
            y += 11;
        }
    }
}
