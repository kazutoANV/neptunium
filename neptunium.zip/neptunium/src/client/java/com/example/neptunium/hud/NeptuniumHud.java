package com.example.neptunium.hud;

import com.example.neptunium.config.NeptuniumConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class NeptuniumHud {
    private NeptuniumHud() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) {
            return;
        }

        int y = 4;
        if (NeptuniumConfig.showFps) {
            context.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 4, y, 0xFFFFFF);
            y += 10;
        }
        if (NeptuniumConfig.showCoords) {
            String xyz = String.format("XYZ: %.1f / %.1f / %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
            context.drawTextWithShadow(mc.textRenderer, xyz, 4, y, 0xFFFFFF);
            y += 10;
        }
        if (NeptuniumConfig.showMemory) {
            Runtime rt = Runtime.getRuntime();
            long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            long maxMb = rt.maxMemory() / 1048576L;
            context.drawTextWithShadow(mc.textRenderer, "RAM: " + usedMb + "/" + maxMb + " MB", 4, y, 0xFFFFFF);
        }
    }
}
