package com.example.neptunium.hud;

import com.example.neptunium.config.NeptuniumConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class NeptuniumHud {
    private static final long START_MS = System.currentTimeMillis();

    private NeptuniumHud() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            try {
                render(context);
            } catch (RuntimeException e) {
                // HUD xatosi o'yinni to'xtatmasin
            }
        });
    }

    private static void render(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) {
            return;
        }

        List<String> lines = new ArrayList<>();
        for (String[][] group : new String[][][]{NeptuniumConfig.OPTIONS, NeptuniumConfig.GENERAL, NeptuniumConfig.ADVANCED}) {
            for (String[] option : group) {
                if (NeptuniumConfig.get(option[0])) {
                    String line = build(mc, option[0]);
                    if (line != null) {
                        lines.add(line);
                    }
                }
            }
        }

        boolean bg = NeptuniumConfig.get("hudbg");
        boolean right = NeptuniumConfig.get("hud_right");
        boolean bottomAlign = NeptuniumConfig.get("hud_bottom");
        boolean compact = NeptuniumConfig.get("hud_compact");
        boolean shadow = NeptuniumConfig.get("hud_shadow");
        boolean hideLabels = NeptuniumConfig.get("hud_hidelabels");
        boolean upper = NeptuniumConfig.get("hud_upper");
        boolean outline = NeptuniumConfig.get("hud_outline");
        boolean center = NeptuniumConfig.get("hud_center");
        boolean title = NeptuniumConfig.get("hud_title");
        boolean wide = NeptuniumConfig.get("hud_wide");
        boolean arrows = NeptuniumConfig.get("hud_arrows");
        boolean numbers = NeptuniumConfig.get("hud_numbers");
        boolean border = NeptuniumConfig.get("hud_border");

        List<String> out = new ArrayList<>();
        if (title) {
            out.add("NEPTUNIUM");
        }
        for (String line : lines) {
            String t = line;
            if (hideLabels && t.contains(": ")) {
                t = t.substring(t.indexOf(": ") + 2);
            }
            if (upper) {
                t = t.toUpperCase();
            }
            out.add(t);
        }

        int lineH = wide ? 14 : (compact ? 9 : 11);
        int color = pickColor();
        int screenW = mc.getWindow().getScaledWidth();
        int screenH = mc.getWindow().getScaledHeight();
        int y = bottomAlign ? screenH - 4 - lineH * out.size() : 4;

        for (int idx = 0; idx < out.size(); idx++) {
            String t = out.get(idx);
            if (numbers) {
                t = (idx + 1) + ". " + t;
            }
            if (arrows) {
                t = "> " + t;
            }
            int width = mc.textRenderer.getWidth(t);
            int x = center ? (screenW - width) / 2 : (right ? screenW - width - 6 : 4);
            if (bg) {
                context.fill(x - 2, y - 1, x + width + 2, y + lineH - 2, 0x88000000);
            }
            if (border) {
                int bx1 = x - 3, by1 = y - 2, bx2 = x + width + 3, by2 = y - 2 + lineH;
                context.fill(bx1, by1, bx2, by1 + 1, 0xFF7FE0C8);
                context.fill(bx1, by2 - 1, bx2, by2, 0xFF7FE0C8);
                context.fill(bx1, by1, bx1 + 1, by2, 0xFF7FE0C8);
                context.fill(bx2 - 1, by1, bx2, by2, 0xFF7FE0C8);
            }
            if (outline) {
                context.drawText(mc.textRenderer, t, x - 1, y, 0xFF000000, false);
                context.drawText(mc.textRenderer, t, x + 1, y, 0xFF000000, false);
                context.drawText(mc.textRenderer, t, x, y - 1, 0xFF000000, false);
                context.drawText(mc.textRenderer, t, x, y + 1, 0xFF000000, false);
            }
            if (shadow) {
                context.drawTextWithShadow(mc.textRenderer, t, x, y, color);
            } else {
                context.drawText(mc.textRenderer, t, x, y, color, false);
            }
            y += lineH;
        }
    }

    private static int pickColor() {
        String[][] colors = {
                {"hud_red", "FFFF5555"}, {"hud_green", "FF55FF55"}, {"hud_blue", "FF5555FF"},
                {"hud_yellow", "FFFFFF55"}, {"hud_pink", "FFFF88CC"}, {"hud_orange", "FFFFAA33"},
                {"hud_cyan", "FF55FFFF"}, {"hud_purple", "FFAA66FF"}, {"hud_gray", "FFAAAAAA"},
                {"hud_gold", "FFFFD700"}, {"hud_lime", "FF88FF00"},
        };
        for (String[] c : colors) {
            if (NeptuniumConfig.get(c[0])) {
                return (int) Long.parseLong(c[1], 16);
            }
        }
        return NeptuniumConfig.get("hud_accent") ? 0xFF7FE0C8 : 0xFFFFFFFF;
    }

    private static String build(MinecraftClient mc, String key) {
        switch (key) {
            case "fps":
                return "FPS: " + mc.getCurrentFps();
            case "xyz":
                return String.format("XYZ: %.1f / %.1f / %.1f",
                        mc.player.getX(), mc.player.getY(), mc.player.getZ());
            case "facing":
                return "Facing: " + mc.player.getHorizontalFacing().asString();
            case "chunk":
                return "Chunk: " + mc.player.getChunkPos().x + ", " + mc.player.getChunkPos().z;
            case "memory": {
                Runtime rt = Runtime.getRuntime();
                long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
                long max = rt.maxMemory() / 1048576L;
                return "RAM: " + used + "/" + max + " MB";
            }
            case "clock":
                return "Clock: " + LocalTime.now().withNano(0);
            case "worldtime":
                return mc.world == null ? null : "World time: " + (mc.world.getTimeOfDay() % 24000L);
            case "java":
                return "Java: " + System.getProperty("java.version");
            case "resolution":
                return "Screen: " + mc.getWindow().getWidth() + "x" + mc.getWindow().getHeight();
            case "gpu": {
                String gpu;
                try {
                    gpu = GL11.glGetString(GL11.GL_RENDERER);
                } catch (RuntimeException e) {
                    gpu = "unknown";
                }
                return "GPU: " + gpu;
            }
            case "ping": {
                if (mc.getNetworkHandler() == null) {
                    return null;
                }
                var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                return entry == null ? null : "Ping: " + entry.getLatency() + " ms";
            }
            case "health":
                return String.format("Health: %.1f / %.1f", mc.player.getHealth(), mc.player.getMaxHealth());
            case "hunger":
                return "Hunger: " + mc.player.getHungerManager().getFoodLevel();
            case "armor":
                return "Armor: " + mc.player.getArmor();
            case "light":
                return mc.world == null ? null
                        : "Light: " + mc.world.getLightLevel(mc.player.getBlockPos());
            case "dimension":
                return mc.world == null ? null
                        : "Dimension: " + mc.world.getRegistryKey().getValue();
            case "gamemode":
                return mc.interactionManager == null ? null
                        : "Mode: " + mc.interactionManager.getCurrentGameMode().toString();
            case "session": {
                long s = (System.currentTimeMillis() - START_MS) / 1000L;
                return String.format("Session: %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
            }
            case "biome": {
                if (mc.world == null) {
                    return null;
                }
                BlockPos pos = mc.player.getBlockPos();
                String name = mc.world.getBiome(pos).getKey()
                        .map(k -> k.getValue().toString()).orElse("?");
                return "Biome: " + name;
            }
            case "speed":
                return String.format("Speed: %.2f blocks/s", mc.player.getVelocity().horizontalLength() * 20.0);
            case "yaw":
                return String.format("Yaw: %.1f", mc.player.getYaw());
            case "pitch":
                return String.format("Pitch: %.1f", mc.player.getPitch());
            case "frametime":
                return String.format("Frame: %.1f ms", 1000.0 / Math.max(1, mc.getCurrentFps()));
            case "playername":
                return "Player: " + mc.player.getName().getString();
            case "server": {
                ServerInfo info = mc.getCurrentServerEntry();
                return "Server: " + (info == null ? "singleplayer" : info.address);
            }
            case "adv_viewdist":
                return "Render distance: " + mc.options.getViewDistance().getValue() + " chunks";
            case "adv_maxfps":
                return "Max FPS setting: " + mc.options.getMaxFps().getValue();
            case "adv_vsync":
                return "VSync setting: " + mc.options.getEnableVsync().getValue();
            case "adv_guiscale":
                return "GUI scale setting: " + mc.options.getGuiScale().getValue();
            case "adv_modcount":
                return "Loaded mods: " + FabricLoader.getInstance().getAllMods().size();
            case "day":
                return mc.world == null ? null : "Day: " + (mc.world.getTimeOfDay() / 24000L);
            case "raining":
                return mc.world == null ? null : "Raining: " + (mc.world.isRaining() ? "yes" : "no");
            case "thunder":
                return mc.world == null ? null : "Thunderstorm: " + (mc.world.isThundering() ? "yes" : "no");
            case "difficulty":
                return mc.world == null ? null : "Difficulty: " + mc.world.getDifficulty().getName();
            case "mcversion":
                return "Minecraft: " + FabricLoader.getInstance().getModContainer("minecraft").map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("unknown");
            case "javavendor":
                return "Java vendor: " + System.getProperty("java.vendor");
            case "air":
                return "Air: " + mc.player.getAir();
            case "xplevel":
                return "XP level: " + mc.player.experienceLevel;
            case "xpprogress":
                return String.format("XP progress: %.0f%%", mc.player.experienceProgress * 100.0f);
            case "falldist":
                return String.format("Fall distance: %.1f", mc.player.fallDistance);
            case "onground":
                return "On ground: " + (mc.player.isOnGround() ? "yes" : "no");
            case "sprinting":
                return "Sprinting: " + (mc.player.isSprinting() ? "yes" : "no");
            case "sneaking":
                return "Sneaking: " + (mc.player.isSneaking() ? "yes" : "no");
            case "flying":
                return "Flying: " + (mc.player.getAbilities().flying ? "yes" : "no");
            case "swimming":
                return "Swimming: " + (mc.player.isSwimming() ? "yes" : "no");
            case "onfire":
                return "On fire: " + (mc.player.isOnFire() ? "yes" : "no");
            case "inwater":
                return "In water: " + (mc.player.isTouchingWater() ? "yes" : "no");
            case "mainhand":
                return "Held: " + mc.player.getMainHandStack().getName().getString();
            case "offhand":
                return "Offhand: " + mc.player.getOffHandStack().getName().getString();
            case "looking":
                return mc.crosshairTarget == null ? "Looking at: none"
                        : "Looking at: " + mc.crosshairTarget.getType().name();
            case "gametick":
                return mc.world == null ? null : "Game ticks: " + mc.world.getTime();
            case "freemem":
                return "Free memory: " + (Runtime.getRuntime().freeMemory() / 1048576L) + " MB";
            case "cpucores":
                return "CPU cores: " + Runtime.getRuntime().availableProcessors();
            case "osname":
                return "OS: " + System.getProperty("os.name");
            case "osver":
                return "OS version: " + System.getProperty("os.version");
            case "tz":
                return "Time zone: " + java.util.TimeZone.getDefault().getID();
            case "adv_brightness":
                return "Brightness: " + mc.options.getGamma().getValue();
            case "adv_particles":
                return "Particles: " + mc.options.getParticles().getValue();
            case "adv_entityshadow":
                return "Entity shadows: " + mc.options.getEntityShadows().getValue();
            case "adv_clouds":
                return "Clouds: " + mc.options.getCloudRenderMode().getValue();
            case "adv_mipmap":
                return "Mipmap levels: " + mc.options.getMipmapLevels().getValue();
            case "adv_entitydist":
                return "Entity distance: " + mc.options.getEntityDistanceScaling().getValue();
            case "adv_simdist":
                return "Simulation distance: " + mc.options.getSimulationDistance().getValue();
            case "adv_fov":
                return "FOV: " + mc.options.getFov().getValue();
            case "adv_sensitivity":
                return "Mouse sensitivity: " + mc.options.getMouseSensitivity().getValue();
            case "adv_autojump":
                return "Auto jump: " + mc.options.getAutoJump().getValue();
            case "adv_chatscale":
                return "Chat scale: " + mc.options.getChatScale().getValue();
            case "adv_bobbing":
                return "View bobbing: " + mc.options.getBobView().getValue();
            case "adv_biomeblend":
                return "Biome blend: " + mc.options.getBiomeBlendRadius().getValue();
            case "adv_loaderver":
                return "Fabric Loader: " + FabricLoader.getInstance().getModContainer("fabricloader")
                        .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("unknown");
            case "adv_fabricapi":
                return "Fabric API: " + (FabricLoader.getInstance().isModLoaded("fabric-api") ? "yes" : "no");
            case "adv_devenv":
                return "Dev environment: " + (FabricLoader.getInstance().isDevelopmentEnvironment() ? "yes" : "no");
            case "adv_gamedir":
                return "Game dir: " + FabricLoader.getInstance().getGameDir();
            case "adv_configdir":
                return "Config dir: " + FabricLoader.getInstance().getConfigDir();
            case "adv_envtype":
                return "Environment: " + FabricLoader.getInstance().getEnvironmentType().name();
            default:
                return null;
        }
    }
}
