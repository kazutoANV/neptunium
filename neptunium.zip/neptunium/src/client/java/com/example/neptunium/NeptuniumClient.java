package com.example.neptunium;

import com.example.neptunium.config.NeptuniumConfig;
import com.example.neptunium.gui.NeptuniumSettingsScreen;
import com.example.neptunium.hud.NeptuniumHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NeptuniumClient implements ClientModInitializer {
    public static final String MOD_ID = "neptunium";

    @Override
    public void onInitializeClient() {
        System.out.println("[Neptunium] Ishga tushdi!");

        NeptuniumConfig.load();
        NeptuniumHud.register();

        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Neptunium"),
                                        b -> client.setScreen(new NeptuniumSettingsScreen(screen)))
                                .dimensions(width / 2 - 100, height - 60, 200, 20)
                                .build());
            }
        });
    }
}
