package com.example.neptunium;

import net.fabricmc.api.ClientModInitializer;

public class NeptuniumClient implements ClientModInitializer {
    public static final String MOD_ID = "neptunium";

    @Override
    public void onInitializeClient() {
        System.out.println("[Neptunium] Ishga tushdi!");
    }
}
