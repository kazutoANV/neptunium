package com.example.neptunium;

import com.example.neptunium.config.NeptuniumConfig;
import com.example.neptunium.gui.NeptuniumSettingsScreen;
import com.example.neptunium.hud.NeptuniumHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NeptuniumClient implements ClientModInitializer {
    public static final String MOD_ID = "neptunium";

    @Override
    public void onInitializeClient() {
        System.out.println("[Neptunium] Ishga tushdi!");

        NeptuniumConfig.load();
        NeptuniumHud.register();

        // Tugma Video Settings'ning pastki chap burchagida turadi
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof VideoOptionsScreen) {
                addOpenButton(client, screen, 8, height - 26, 110);
            }
        });
    }

    private static void addOpenButton(MinecraftClient client, Screen parent, int x, int y, int w) {
        Screens.getButtons(parent).add(
                ButtonWidget.builder(Text.literal("Neptunium"),
                                b -> client.setScreen(new NeptuniumSettingsScreen(parent)))
                        .dimensions(x, y, w, 20)
                        .build());
    }
}
