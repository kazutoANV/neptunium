package com.example.neptunium.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NeptuniumConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("neptunium.json");

    public static boolean showFps = true;
    public static boolean showCoords = false;
    public static boolean showMemory = false;

    private NeptuniumConfig() {
    }

    public static void load() {
        if (!Files.exists(PATH)) {
            return;
        }
        try {
            String json = Files.readString(PATH);
            Settings s = GSON.fromJson(json, Settings.class);
            if (s != null) {
                showFps = s.showFps;
                showCoords = s.showCoords;
                showMemory = s.showMemory;
            }
        } catch (IOException | RuntimeException e) {
            System.out.println("[Neptunium] Config o'qib bo'lmadi: " + e.getMessage());
        }
    }

    public static void save() {
        Settings s = new Settings();
        s.showFps = showFps;
        s.showCoords = showCoords;
        s.showMemory = showMemory;
        try {
            Files.writeString(PATH, GSON.toJson(s));
        } catch (IOException e) {
            System.out.println("[Neptunium] Config saqlab bo'lmadi: " + e.getMessage());
        }
    }

    private static final class Settings {
        boolean showFps = true;
        boolean showCoords = false;
        boolean showMemory = false;
    }
}
