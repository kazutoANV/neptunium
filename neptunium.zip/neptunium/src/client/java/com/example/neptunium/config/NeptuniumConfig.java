package com.example.neptunium.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class NeptuniumConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Boolean>>() {}.getType();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("neptunium.json");

    /** Each option: {key, display name, default value}. */
    public static final String[][] OPTIONS = {
            {"fps", "FPS counter", "true"},
            {"xyz", "Coordinates (XYZ)", "false"},
            {"facing", "Facing direction", "false"},
            {"chunk", "Chunk coordinates", "false"},
            {"memory", "Memory (RAM)", "false"},
            {"clock", "System clock", "false"},
            {"worldtime", "World time", "false"},
            {"java", "Java version", "false"},
            {"resolution", "Screen size", "false"},
            {"gpu", "GPU name", "false"},
            {"hudbg", "HUD background", "true"},
    };

    /** General category options. */
    public static final String[][] GENERAL = {
            {"ping", "Ping (ms)", "false"},
            {"health", "Health", "false"},
            {"hunger", "Hunger", "false"},
            {"armor", "Armor", "false"},
            {"light", "Light level", "false"},
            {"dimension", "Dimension", "false"},
            {"gamemode", "Game mode", "false"},
            {"session", "Session time", "false"},
            {"biome", "Biome", "false"},
            {"speed", "Speed (blocks/s)", "false"},
            {"yaw", "Yaw", "false"},
            {"pitch", "Pitch", "false"},
            {"frametime", "Frame time (ms)", "false"},
            {"playername", "Player name", "false"},
            {"server", "Server address", "false"},
            {"day", "Day count", "false"},
            {"raining", "Raining", "false"},
            {"thunder", "Thunderstorm", "false"},
            {"difficulty", "Difficulty", "false"},
            {"mcversion", "Minecraft version", "false"},
            {"javavendor", "Java vendor", "false"},
            {"air", "Air supply", "false"},
            {"xplevel", "Experience level", "false"},
            {"xpprogress", "Experience progress", "false"},
            {"falldist", "Fall distance", "false"},
            {"onground", "On ground", "false"},
            {"sprinting", "Sprinting", "false"},
            {"sneaking", "Sneaking", "false"},
            {"flying", "Flying", "false"},
            {"swimming", "Swimming", "false"},
            {"onfire", "On fire", "false"},
            {"inwater", "In water", "false"},
            {"mainhand", "Held item", "false"},
            {"offhand", "Offhand item", "false"},
            {"looking", "Looking at", "false"},
            {"gametick", "Game ticks", "false"},
            {"freemem", "Free memory (MB)", "false"},
            {"cpucores", "CPU cores", "false"},
            {"osname", "OS name", "false"},
            {"osver", "OS version", "false"},
            {"tz", "Time zone", "false"},
    };

    /** Appearance category options. */
    public static final String[][] APPEARANCE = {
            {"hud_shadow", "Text shadow", "true"},
            {"hud_right", "Align right", "false"},
            {"hud_bottom", "Align bottom", "false"},
            {"hud_compact", "Compact spacing", "false"},
            {"hud_accent", "Accent text color", "false"},
            {"hud_hidelabels", "Hide labels", "false"},
            {"hud_upper", "Uppercase text", "false"},
            {"hud_outline", "Text outline", "false"},
            {"hud_center", "Center horizontally", "false"},
            {"hud_title", "Show title header", "false"},
            {"hud_wide", "Wide spacing", "false"},
            {"hud_arrows", "Arrow prefix", "false"},
            {"hud_numbers", "Numbered lines", "false"},
            {"hud_border", "Line border", "false"},
            {"hud_red", "Color: red", "false"},
            {"hud_green", "Color: green", "false"},
            {"hud_blue", "Color: blue", "false"},
            {"hud_yellow", "Color: yellow", "false"},
            {"hud_pink", "Color: pink", "false"},
            {"hud_orange", "Color: orange", "false"},
            {"hud_cyan", "Color: cyan", "false"},
            {"hud_purple", "Color: purple", "false"},
            {"hud_gray", "Color: gray", "false"},
            {"hud_gold", "Color: gold", "false"},
            {"hud_lime", "Color: lime", "false"},
    };

    /** Advanced category options (read-only game settings). */
    public static final String[][] ADVANCED = {
            {"adv_viewdist", "Render distance setting", "false"},
            {"adv_maxfps", "Max FPS setting", "false"},
            {"adv_vsync", "VSync setting", "false"},
            {"adv_guiscale", "GUI scale setting", "false"},
            {"adv_modcount", "Loaded mods count", "false"},
            {"adv_brightness", "Brightness setting", "false"},
            {"adv_particles", "Particles setting", "false"},
            {"adv_entityshadow", "Entity shadows setting", "false"},
            {"adv_clouds", "Clouds setting", "false"},
            {"adv_mipmap", "Mipmap levels setting", "false"},
            {"adv_entitydist", "Entity distance setting", "false"},
            {"adv_simdist", "Simulation distance setting", "false"},
            {"adv_fov", "FOV setting", "false"},
            {"adv_sensitivity", "Mouse sensitivity setting", "false"},
            {"adv_autojump", "Auto jump setting", "false"},
            {"adv_chatscale", "Chat scale setting", "false"},
            {"adv_bobbing", "View bobbing setting", "false"},
            {"adv_graphics", "Graphics mode setting", "false"},
            {"adv_biomeblend", "Biome blend radius setting", "false"},
            {"adv_loaderver", "Fabric Loader version", "false"},
            {"adv_fabricapi", "Fabric API installed", "false"},
            {"adv_devenv", "Development environment", "false"},
            {"adv_gamedir", "Game directory", "false"},
            {"adv_configdir", "Config directory", "false"},
            {"adv_envtype", "Environment type", "false"},
    };

    private static final Map<String, Boolean> VALUES = new LinkedHashMap<>();

    static {
        for (String[][] group : new String[][][]{OPTIONS, GENERAL, APPEARANCE, ADVANCED}) {
            for (String[] o : group) {
                VALUES.put(o[0], Boolean.parseBoolean(o[2]));
            }
        }
    }

    private NeptuniumConfig() {
    }

    public static boolean get(String key) {
        return VALUES.getOrDefault(key, false);
    }

    public static void set(String key, boolean value) {
        VALUES.put(key, value);
    }

    public static void load() {
        if (!Files.exists(PATH)) {
            return;
        }
        try {
            Map<String, Boolean> saved = GSON.fromJson(Files.readString(PATH), MAP_TYPE);
            if (saved != null) {
                for (Map.Entry<String, Boolean> e : saved.entrySet()) {
                    if (VALUES.containsKey(e.getKey()) && e.getValue() != null) {
                        VALUES.put(e.getKey(), e.getValue());
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            System.out.println("[Neptunium] Failed to read config: " + e.getMessage());
        }
    }

    public static void save() {
        try {
            Files.writeString(PATH, GSON.toJson(VALUES, MAP_TYPE));
        } catch (IOException e) {
            System.out.println("[Neptunium] Failed to save config: " + e.getMessage());
        }
    }
}
