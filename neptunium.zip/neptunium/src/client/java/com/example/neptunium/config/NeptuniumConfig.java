package com.example.neptunium.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class NeptuniumConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Boolean>>() {}.getType();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("neptunium.json");

    /** Har bir sozlam: {kalit, ko'rinadigan nom, standart qiymat}. Yangi sozlam shu yerga qo'shiladi. */
    public static final String[][] OPTIONS = {
            {"fps", "FPS ko'rsatkichi", "true"},
            {"xyz", "Koordinatalar (XYZ)", "false"},
            {"facing", "Yo'nalish", "false"},
            {"chunk", "Chunk koordinatasi", "false"},
            {"memory", "Xotira (RAM)", "false"},
            {"clock", "Tizim soati", "false"},
            {"worldtime", "Dunyo vaqti", "false"},
            {"java", "Java versiyasi", "false"},
            {"resolution", "Ekran o'lchami", "false"},
            {"gpu", "GPU nomi", "false"},
            {"hudbg", "HUD foni", "true"},
    };

    private static final Map<String, Boolean> VALUES = new LinkedHashMap<>();

    static {
        for (String[] o : OPTIONS) {
            VALUES.put(o[0], Boolean.parseBoolean(o[2]));
        }
    }

    private NeptuniumConfig() {
    }

    public static boolean get(String key) {
        return VALUES.getOrDefault(key, false);
    }

    public static void set(String key, boolean value) {
        VALUES.put(key, value);
    }

    public static void load() {
        if (!Files.exists(PATH)) {
            return;
        }
        try {
            Map<String, Boolean> saved = GSON.fromJson(Files.readString(PATH), MAP_TYPE);
            if (saved != null) {
                for (Map.Entry<String, Boolean> e : saved.entrySet()) {
                    if (VALUES.containsKey(e.getKey()) && e.getValue() != null) {
                        VALUES.put(e.getKey(), e.getValue());
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            System.out.println("[Neptunium] Config o'qib bo'lmadi: " + e.getMessage());
        }
    }

    public static void save() {
        try {
            Files.writeString(PATH, GSON.toJson(VALUES, MAP_TYPE));
        } catch (IOException e) {
            System.out.println("[Neptunium] Config saqlab bo'lmadi: " + e.getMessage());
        }
    }
}
