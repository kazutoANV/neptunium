package com.example.neptunium.gui;

import com.example.neptunium.config.NeptuniumConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class NeptuniumSettingsScreen extends Screen {
    private final Screen parent;

    public NeptuniumSettingsScreen(Screen parent) {
        super(Text.literal("Neptunium"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 4;

        this.addDrawableChild(toggle(x, y, "FPS ko'rsatkichi",
                () -> NeptuniumConfig.showFps, v -> NeptuniumConfig.showFps = v));
        this.addDrawableChild(toggle(x, y + 24, "Koordinatalar",
                () -> NeptuniumConfig.showCoords, v -> NeptuniumConfig.showCoords = v));
        this.addDrawableChild(toggle(x, y + 48, "Xotira (RAM)",
                () -> NeptuniumConfig.showMemory, v -> NeptuniumConfig.showMemory = v));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Tayyor"), b -> close())
                .dimensions(x, this.height - 40, 200, 20)
                .build());
    }

    private ButtonWidget toggle(int x, int y, String name, Supplier<Boolean> get, Consumer<Boolean> set) {
        return ButtonWidget.builder(label(name, get.get()), b -> {
            set.accept(!get.get());
            NeptuniumConfig.save();
            b.setMessage(label(name, get.get()));
        }).dimensions(x, y, 200, 20).build();
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "Yoqilgan" : "O'chirilgan"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
