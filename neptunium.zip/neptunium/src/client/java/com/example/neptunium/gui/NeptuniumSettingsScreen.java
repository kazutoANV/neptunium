package com.example.neptunium.gui;

import com.example.neptunium.config.NeptuniumConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NeptuniumSettingsScreen extends Screen {
    private static final int ACCENT = 0xFF7FE0C8;
    private static final int PANEL = 0xC8101418;
    private static final int BOX = 0x80181C21;
    private static final int HOVER = 0x33FFFFFF;
    private static final int TEXT = 0xFFE6E6E6;
    private static final int TEXT_DIM = 0xFF8A9099;
    private static final String[] CATEGORIES = {"HUD", "Umumiy", "Ko'rinish", "Ilg'or"};
    private static final int CAT_TOP = 64;
    private static final int CAT_H = 18;
    private static final int ROW_TOP = 52;
    private static final int ROW_H = 18;

    private final Screen parent;
    private int selected = 0;

    private int sideX;
    private int sideW;
    private int mainX;
    private int mainW;

    public NeptuniumSettingsScreen(Screen parent) {
        super(Text.literal("Neptunium"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        layout();
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Qo'llash"),
                        b -> NeptuniumConfig.save())
                .dimensions(this.width - 216, this.height - 26, 100, 20)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Tayyor"), b -> close())
                .dimensions(this.width - 110, this.height - 26, 100, 20)
                .build());
    }

    private void layout() {
        sideX = 8;
        sideW = Math.min(120, this.width / 3);
        mainX = sideX + sideW + 6;
        mainW = this.width - mainX - 8;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        layout();

        // Yuqori sarlavha paneli
        context.fill(sideX, 8, this.width - 8, 26, PANEL);
        context.drawTextWithShadow(this.textRenderer, "Neptunium", sideX + 8, 12, ACCENT);

        // Chap menyu
        context.fill(sideX, 30, sideX + sideW, this.height - 34, PANEL);
        context.drawTextWithShadow(this.textRenderer, "Neptunium", sideX + 8, 36, ACCENT);
        context.drawTextWithShadow(this.textRenderer, "v0.1.0", sideX + 8, 46, TEXT_DIM);

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = CAT_TOP + i * CAT_H;
            boolean active = i == selected;
            if (active) {
                context.fill(sideX, y, sideX + sideW, y + CAT_H, 0x33FFFFFF);
                context.fill(sideX, y, sideX + 3, y + CAT_H, ACCENT);
            }
            context.drawTextWithShadow(this.textRenderer, CATEGORIES[i], sideX + 10, y + 5,
                    active ? ACCENT : TEXT);
        }

        // O'ng asosiy panel
        context.fill(mainX, 30, mainX + mainW, this.height - 34, PANEL);
        context.fill(mainX, 30, mainX + mainW, 44, 0x80000000);
        context.drawTextWithShadow(this.textRenderer, CATEGORIES[selected] + " sozlamalari",
                mainX + 8, 34, ACCENT);

        if (selected == 0) {
            String[][] options = NeptuniumConfig.OPTIONS;
            int boxBottom = ROW_TOP + options.length * ROW_H + 4;
            context.fill(mainX + 4, ROW_TOP - 4, mainX + mainW - 4, boxBottom, BOX);

            for (int i = 0; i < options.length; i++) {
                int y = ROW_TOP + i * ROW_H;
                boolean hovered = mouseX >= mainX + 4 && mouseX < mainX + mainW - 4
                        && mouseY >= y && mouseY < y + ROW_H;
                if (hovered) {
                    context.fill(mainX + 4, y, mainX + mainW - 4, y + ROW_H, HOVER);
                }

                context.drawTextWithShadow(this.textRenderer, options[i][1], mainX + 10, y + 5, TEXT);

                int boxX = mainX + mainW - 22;
                int boxY = y + 3;
                boolean on = NeptuniumConfig.get(options[i][0]);
                context.fill(boxX, boxY, boxX + 12, boxY + 12, on ? ACCENT : 0xFF5A6068);
                context.fill(boxX + 1, boxY + 1, boxX + 11, boxY + 11, on ? ACCENT : 0xFF1B1F24);
                if (on) {
                    context.fill(boxX + 3, boxY + 3, boxX + 9, boxY + 9, ACCENT);
                }
            }
        } else {
            context.drawTextWithShadow(this.textRenderer,
                    "Bu bo'lim keyingi bosqichda qo'shiladi.", mainX + 10, ROW_TOP, TEXT_DIM);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }

        // Chap menyu bo'limlari
        if (mouseX >= sideX && mouseX < sideX + sideW
                && mouseY >= CAT_TOP && mouseY < CAT_TOP + CATEGORIES.length * CAT_H) {
            selected = (int) ((mouseY - CAT_TOP) / CAT_H);
            return true;
        }

        // Sozlama qatorlari
        if (selected == 0) {
            String[][] options = NeptuniumConfig.OPTIONS;
            for (int i = 0; i < options.length; i++) {
                int y = ROW_TOP + i * ROW_H;
                if (mouseX >= mainX + 4 && mouseX < mainX + mainW - 4
                        && mouseY >= y && mouseY < y + ROW_H) {
                    String key = options[i][0];
                    NeptuniumConfig.set(key, !NeptuniumConfig.get(key));
                    NeptuniumConfig.save();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
