package com.example.neptunium.gui;

import com.example.neptunium.config.NeptuniumConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NeptuniumSettingsScreen extends Screen {
    private final Screen parent;

    public NeptuniumSettingsScreen(Screen parent) {
        super(Text.literal("Neptunium"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        String[][] options = NeptuniumConfig.OPTIONS;
        for (int i = 0; i < options.length; i++) {
            int col = i % 2;
            int row = i / 2;
            int x = this.width / 2 - 205 + col * 210;
            int y = 40 + row * 24;
            this.addDrawableChild(toggle(x, y, options[i][0], options[i][1]));
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Tayyor"), b -> close())
                .dimensions(this.width / 2 - 100, this.height - 30, 200, 20)
                .build());
    }

    private ButtonWidget toggle(int x, int y, String key, String name) {
        return ButtonWidget.builder(label(name, NeptuniumConfig.get(key)), b -> {
            NeptuniumConfig.set(key, !NeptuniumConfig.get(key));
            NeptuniumConfig.save();
            b.setMessage(label(name, NeptuniumConfig.get(key)));
        }).dimensions(x, y, 200, 20).build();
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "Yoqilgan" : "O'chirilgan"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
