package com.example.neptunium.gui;

import com.example.neptunium.config.NeptuniumConfig;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NeptuniumSettingsScreen extends Screen {
    private static final int ACCENT = 0xFF7FE0C8;
    private static final int PANEL = 0xE0121619;
    private static final int HEADER = 0xE0181C21;
    private static final int ROW_HOVER = 0x33FFFFFF;
    private static final int ROW_SELECTED = 0x2A7FE0C8;
    private static final int TEXT = 0xFFEAEAEA;
    private static final int TEXT_DIM = 0xFF8A9099;
    private static final int BORDER_OFF = 0xFF5A6068;
    private static final int BOX_OFF = 0xFF1B1F24;

    private static final String[] CATEGORIES = {"HUD", "General", "Appearance", "Advanced"};
    private static final int ROW_H = 18;
    private static final int SIDE_TOP = 30;
    private static final int BOTTOM_BAR = 30;
    private static final int ROWS_TOP = 56;

    private final Screen parent;
    private int selected = 0;
    private int scroll = 0;

    private int sideX, sideW, mainX, mainW, bottom;

    public NeptuniumSettingsScreen(Screen parent) {
        super(Text.literal("Neptunium"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        layout();
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Up"), b -> {
                    scroll = Math.max(0, scroll - 1);
                })
                .dimensions(mainX + mainW - 90, SIDE_TOP + 2, 40, 16)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Down"), b -> {
                    scroll = Math.min(maxScroll(), scroll + 1);
                })
                .dimensions(mainX + mainW - 46, SIDE_TOP + 2, 40, 16)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Apply"),
                        b -> NeptuniumConfig.save())
                .dimensions(this.width - 216, this.height - 26, 100, 20)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width - 110, this.height - 26, 100, 20)
                .build());
    }

    private void layout() {
        sideX = 6;
        sideW = Math.min(110, this.width / 3);
        mainX = sideX + sideW + 6;
        mainW = this.width - mainX - 6;
        bottom = this.height - BOTTOM_BAR;
    }

    /** Options shown for the selected category, or null if the category has none yet. */
    private String[][] currentOptions() {
        if (selected == 0) {
            return NeptuniumConfig.OPTIONS;
        }
        if (selected == 1) {
            return NeptuniumConfig.GENERAL;
        }
        if (selected == 2) {
            return NeptuniumConfig.APPEARANCE;
        }
        if (selected == 3) {
            return NeptuniumConfig.ADVANCED;
        }
        return null;
    }

    private int visibleRows() {
        int avail = bottom - ROWS_TOP - 4;
        return Math.max(1, avail / ROW_H);
    }

    private int maxScroll() {
        String[][] o = currentOptions();
        if (o == null) {
            return 0;
        }
        int rowsTotal = (o.length + 1) / 2;
        return Math.max(0, rowsTotal - visibleRows());
    }

    private int colWidth() {
        return (mainW - 12) / 2;
    }

    private int rowX(int i) {
        return mainX + 4 + (i % 2) * (colWidth() + 4);
    }

    private int rowY(int i) {
        return ROWS_TOP + (i / 2) * ROW_H;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        layout();

        // Title bar
        context.fill(sideX, 6, this.width - 6, 24, PANEL);
        context.drawTextWithShadow(this.textRenderer, "Neptunium", sideX + 8, 11, ACCENT);
        context.drawTextWithShadow(this.textRenderer, "v0.1.0", this.width - 50, 11, TEXT_DIM);

        // Sidebar
        context.fill(sideX, SIDE_TOP, sideX + sideW, bottom, PANEL);
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = SIDE_TOP + 8 + i * 20;
            boolean active = i == selected;
            if (active) {
                context.fill(sideX, y, sideX + sideW, y + 18, ROW_SELECTED);
                context.fill(sideX, y, sideX + 2, y + 18, ACCENT);
            }
            context.drawTextWithShadow(this.textRenderer, CATEGORIES[i], sideX + 10, y + 5,
                    active ? ACCENT : TEXT);
        }

        // Main panel
        context.fill(mainX, SIDE_TOP, mainX + mainW, bottom, PANEL);
        context.fill(mainX, SIDE_TOP, mainX + mainW, SIDE_TOP + 20, HEADER);
        context.drawTextWithShadow(this.textRenderer, CATEGORIES[selected] + " settings",
                mainX + 8, SIDE_TOP + 6, ACCENT);

        String[][] options = currentOptions();
        if (options == null) {
            context.drawTextWithShadow(this.textRenderer, "Coming in the next update.",
                    mainX + 8, SIDE_TOP + 28, TEXT_DIM);
            return;
        }

        scroll = Math.min(scroll, maxScroll());
        int shown = visibleRows() * 2;
        for (int r = 0; r < shown; r++) {
            int i = scroll * 2 + r;
            if (i >= options.length) {
                break;
            }
            int x = rowX(r);
            int y = rowY(r);
            int w = colWidth();
            boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + ROW_H;
            if (hovered) {
                context.fill(x, y, x + w, y + ROW_H, ROW_HOVER);
            }

            context.drawTextWithShadow(this.textRenderer, options[i][1], x + 4, y + 5, TEXT);

            boolean on = NeptuniumConfig.get(options[i][0]);
            int boxX = x + w - 16;
            int boxY = y + 3;
            context.fill(boxX, boxY, boxX + 12, boxY + 12, on ? ACCENT : BORDER_OFF);
            context.fill(boxX + 1, boxY + 1, boxX + 11, boxY + 11, on ? ACCENT : BOX_OFF);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        if (super.mouseClicked(click, doubled)) {
            return true;
        }

        // Sidebar categories
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = SIDE_TOP + 8 + i * 20;
            if (mouseX >= sideX && mouseX < sideX + sideW && mouseY >= y && mouseY < y + 18) {
                selected = i;
                scroll = 0;
                return true;
            }
        }

        // Option rows
        String[][] options = currentOptions();
        if (options != null) {
            int shown = visibleRows() * 2;
            for (int r = 0; r < shown; r++) {
                int i = scroll * 2 + r;
                if (i >= options.length) {
                    break;
                }
                int x = rowX(r);
                int y = rowY(r);
                if (mouseX >= x && mouseX < x + colWidth() && mouseY >= y && mouseY < y + ROW_H) {
                    String key = options[i][0];
                    NeptuniumConfig.set(key, !NeptuniumConfig.get(key));
                    NeptuniumConfig.save();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
