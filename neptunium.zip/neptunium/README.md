# Neptunium

Minecraft Java Edition uchun Fabric mod. Render optimizatsiyasiga mo'ljallangan (boshlang'ich skelet).

## Talablar

- JDK 21
- Fabric uchun versiyalar: https://fabricmc.net/develop

## Ishga tushirish

1. `gradle.properties` faylidagi `REPLACE_ME` qiymatlarini fabricmc.net/develop saytidan oling.
2. Gradle wrapper yarating (bir marta): `gradle wrapper`
3. Build: `./gradlew build` (Windows: `gradlew.bat build`)
4. Tayyor jar `build/libs/` papkasida bo'ladi.

## GitHub'ga yuklash

```
git init
git add .
git commit -m "Initial Neptunium skeleton"
git branch -M main
git remote add origin https://github.com/USERNAME/neptunium.git
git push -u origin main
```

## Litsenziya

MIT
